/*IlwisObjects is a framework for analysis, processing and visualization of remote sensing and gis data
Copyright (C) 2018  52n North

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#include "kernel.h"
#include "raster.h"
#include "ilwiscontext.h"
#include "connectorinterface.h"
#include "geometries.h"

using namespace Ilwis;

Grid::Grid() {

}


PIXVALUETYPE Grid::value(const Pixel& pix) {
	auto lpos = linearPosition(pix);
	if (lpos != i64UNDEF && lpos < size())
		return at(lpos);
	return rUNDEF;
}

PIXVALUETYPE& Grid::valueRef(const Pixel& pix) {
	auto lpos = linearPosition(pix);
	if (lpos != i64UNDEF && lpos < size())
		return at(lpos);
	_dummy = rUNDEF;
	return _dummy;
}

void Grid::value(const Pixel& pix, PIXVALUETYPE v) {
	auto lpos = linearPosition(pix);
	if (lpos != i64UNDEF && lpos < size())
		at(lpos) = v;
}

void Grid::dimensions(const Size<>& sz, bool resizeZ) {
	if (resizeZ) {
		if (sz.xsize() == _gridDimensions.xsize() && sz.ysize() == _gridDimensions.ysize() && sz.zsize() != _gridDimensions.zsize()) {
			resize(sz.linearSize());
		}
	}
	else {
		clear();
		_gridDimensions = sz;
	}
}

Size<> Grid::dimensions() const {
	return _gridDimensions;
}

quint64 Grid::linearPosition(const Pixel& pix) const {
	quint64 lpos = i64UNDEF;
	if (_gridDimensions.isValid()) {
		int z = isNumericalUndef(pix.z) ? 0 : pix.z;
		lpos = pix.x + pix.y * _gridDimensions.xsize() + z * _gridDimensions.xsize() *  _gridDimensions.ysize();
	}
	return lpos;
}

bool Grid::isValid() const {
	return _gridDimensions.isValid();
}



