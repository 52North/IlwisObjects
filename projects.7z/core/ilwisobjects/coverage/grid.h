/*IlwisObjects is a framework for analysis, processing and visualization of remote sensing and gis data
Copyright (C) 2018  52n North

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

#ifndef Grid_H
#define Grid_H

#include <list>
#include <mutex>
#include <QDir>
#include <QTemporaryFile>
#include <iostream>
#include "kernel.h"
#include "errorobject.h"
#include "size.h"
#include "location.h"
#include "stxxl/vector"

namespace Ilwis {



	class KERNELSHARED_EXPORT Grid : public stxxl::VECTOR_GENERATOR<double>::result

	{
	public:
		Grid();


		PIXVALUETYPE value(const Pixel& pix) ;
		PIXVALUETYPE& valueRef(const Pixel& pix);
		void value(const Pixel& pix, PIXVALUETYPE v);

		void dimensions(const Size<>& sz, bool resizeZ=false);
		Size<> dimensions() const;
		quint64 linearPosition(const Pixel& pix) const;

		bool isValid() const;
	protected:

	private:
		Size<> _gridDimensions;
		double _dummy = rUNDEF;
	};
}





#endif // Grid_H
